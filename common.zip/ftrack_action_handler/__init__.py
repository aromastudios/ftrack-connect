# :coding: utf-8
# :copyright: Copyright (c) 2017 ftrack

from ._version import __version__
