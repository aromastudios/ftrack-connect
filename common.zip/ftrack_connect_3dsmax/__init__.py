# :coding: utf-8
# :copyright: Copyright (c) 2016 ftrack

from ._version import __version__
