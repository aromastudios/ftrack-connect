# :coding: utf-8
# :copyright: Copyright (c) 2016 ftrack

IMPORT_IMPORT_MODE = 'Import'
OBJECT_XREF_IMPORT_MODE = 'Object XRef'
SCENE_XREF_IMPORT_MODE = 'Scene XRef'
