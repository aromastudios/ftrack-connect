# :coding: utf-8
# :copyright: Copyright (c) 2016 ftrack

from maxcon import Connector
from ftrack_connect.connector import FTAssetHandlerInstance
