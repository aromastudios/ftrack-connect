# :coding: utf-8
# :copyright: Copyright (c) 2016 ftrack

import MaxPlus

FTRACK_ASSET_HELPER_CLASS_ID = MaxPlus.Class_ID(0x5c8d275e, 0x677d591c)
