# :coding: utf-8
# :copyright: Copyright (c) 2014 ftrack

# Import QtSvg and QtXml to force load libraries needed to display
# SVG on Windows.
from QtExt import QtSvg
from QtExt import QtXml


# Load UI resources such as icons.
from . import resource as _resource
