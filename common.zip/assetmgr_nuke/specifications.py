from FnAssetAPI.specifications import FileSpecification
from FnAssetAPI.specifications.Specification import TypedProperty as P

__all__ = ['NukeScriptSpecification',]

## @todo clean up code that uses these
from FnAssetAPI.specifications import NukeScriptSpecification


