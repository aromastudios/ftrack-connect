
kNukMenu_Preferences = "Preferences..."
kNukeMenu_PublishScript = "{publish} Script..."
kNukeMenu_RePublishScript = "{publish} Script to a New Version"
kNukeMenu_OpenPublishedScript = "Open {published} Script..."


