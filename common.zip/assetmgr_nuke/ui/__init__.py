import actions

from . import events
events.registerUIEvents()

from . import interface
interface.buildStaticUI()

