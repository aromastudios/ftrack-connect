# :coding: utf-8
# :copyright: Copyright (c) 2014 ftrack

import ftrack_connect_foundry.scheme
ftrack_connect_foundry.scheme.registerScheme('ftrack')
