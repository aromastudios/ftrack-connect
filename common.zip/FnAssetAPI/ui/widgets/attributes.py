
kConnectSelectionChanged = 1 # Assumes the object has a selectionChanged([]) method
kCreateApplicationPanel = 2  # Will create a panel in the Host's UI.
