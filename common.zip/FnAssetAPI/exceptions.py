class BaseException(RuntimeError):
  """

  The BaseException class should be used for all exceptions raise by Managers
  and any API-related exceptions raised in a Host. These exceptions are
  guaranteed to properly bridge across the C plugin divide...

  """
  pass


class UserCanceled(BaseException):
  """

  Thrown by the progress mechanism to interrupt execution whenever the user
  cancels an action (perhaps using an on-screen button).

  """
  def __str__(self):
    return "Operation Canceled"

##
# @name Entity related Exceptions
#
## @{

class BaseEntityException(BaseException):
  """

  A base Exception for any @ref Entity related errors to ensure consistent
  presentation and encapsulation of the associated @ref entity_reference.

  """

  def __init__(self, message, entityReference=None):
    """

    @param entityReference str, The entity reference associated with the error.
    This should be provided wherever known, and will be printed along with the
    message in any traceback/etc... As such, there is no need to embedded the
    entity reference in the message when using this exception type.

    """
    BaseException.__init__(self, message)
    self.ref = entityReference

  def __str__(self):
    string = BaseException.__str__(self)
    return "%s (%s)" % (string, self.ref)



class InvalidEntityReference(BaseEntityException):
  """

  Thrown whenever an Entity-based action is performed on a mal-formed or
  unrecognised @ref entity_reference.

  """
  def __init__(self, message="Invalid Entity Reference", entityReference=None):
    super(InvalidEntityReference, self).__init__(message, entityReference)


class EntityResolutionError(BaseEntityException):
  """

  Thrown during @ref Entity resolution,  if the
  Entity is valid, but has no meaningful @ref primary_string, or it can't be
  retrieved for some other reason. It is also used during version finalisation
  and any other entity-based operations on a valid @ref entity_reference that
  fail for some reason.

  """
  def __init__(self, message="Error resolving entity", entityReference=None):
    super(EntityResolutionError, self).__init__(message, entityReference)


class DuplicateEntityError(BaseEntityException):
  pass


class BaseEntityInteractionError(BaseEntityException):
  pass


class PreflightError(BaseEntityInteractionError):
  """

  Thrown to represent some error during pre-flight that isn't due to any
  specific of the @ref entity_reference itself.

  """
  pass


class RegistrationError(BaseEntityInteractionError):
  """

  Thrown to represent some error during registration that isn't due to any
  specific of the @ref entity_reference itself.

  """
  pass

## @}


class ManagerError(BaseException):
  pass


class StateError(BaseException):
  """

  Thrown by Managers in error situations relating to the managerInterfaceState
  object.

  """
  pass


class RetryableError(BaseException):
  pass


class PluginError(BaseException):
  pass


class InvalidCommand(BaseException):
  pass

